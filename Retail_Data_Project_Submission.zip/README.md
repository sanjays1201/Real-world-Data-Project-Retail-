
# Retail Sales Data Science Project
## Finance / Retail Domain — End-to-End Analysis and Revenue Prediction

### Objective
Analyze retail transaction data, identify sales/profit patterns, visualize findings, and build a machine-learning model to predict transaction revenue.

### 1. Load Dataset
```python
import pandas as pd
df = pd.read_csv("retail_sales_dataset.csv")
df["Order_Date"] = pd.to_datetime(df["Order_Date"])
df.head()
```

### 2. Data Understanding & Cleaning
- Rows: 1,200
- Columns: 16
- Duplicate rows: 0
- Missing values: 0
- Date range: 2025-01-01 to 2026-06-30

The dataset contains order date, product, category, geography, sales channel, customer segment, quantity, price, discount, revenue, cost and profit.

### 3. Key KPIs
- Total Revenue: ₹695,677.96
- Total Profit: ₹202,771.69
- Total Orders: 1,200
- Units Sold: 3,626
- Average Order Revenue: ₹579.73
- Profit Margin: 29.15%

### 4. Exploratory Data Analysis
Use the generated charts:
1. `01_monthly_revenue.png` — monthly revenue trend.
2. `02_category_revenue.png` — category performance.
3. `03_region_profit.png` — regional profitability.
4. `04_discount_profit.png` — relationship between discount and profit.

### 5. Business Findings
- Best revenue category: Electronics.
- Best revenue region: South.
- Highest-profit region: South.
- Revenue and profit vary by category, region and channel.
- Higher discounts should be monitored because discounting can reduce transaction-level profit.
- Monthly trends can support inventory and promotional planning.

### 6. Revenue Prediction Model
A Random Forest Regressor predicts transaction revenue using:
`Quantity, Unit_Price, Discount, Category, Region, Channel, Customer_Segment`.

Test results:
- MAE: ₹27.93
- RMSE: ₹65.65
- R²: 0.9952

### 7. Conclusion
The project demonstrates an end-to-end retail data science workflow: data preparation → EDA → visualization → business insights → machine-learning prediction. The results can help a retailer understand category and regional performance and support data-driven sales planning.

### Dataset note
This submission uses a **synthetic practice retail transaction dataset** designed to resemble real retail records. It is intended for applied-learning demonstration and does not claim to represent a real company's confidential data.
